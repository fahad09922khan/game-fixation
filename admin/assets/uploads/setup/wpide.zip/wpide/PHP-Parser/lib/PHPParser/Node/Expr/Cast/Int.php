<?php

class PHPParser_Node_Expr_Cast_Int extends PHPParser_Node_Expr_Cast
{
}